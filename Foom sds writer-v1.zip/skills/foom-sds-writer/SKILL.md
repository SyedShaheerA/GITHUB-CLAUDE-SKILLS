---
name: foom-sds-writer
description: Create a Software Design Specification (SDS / Software Design Document / SDD) for foom GmbH in IEEE 1016 / ISO/IEC/IEEE format, either as a blank fill-in template or as a completed document built from the user's code, notes, SRS or description. Use this skill whenever the user mentions an SDS, SDD, software design document, design specification, architecture and design write-up, IEEE 1016, "design doc for a foom project", or wants to document the design of a data pipeline, ML or soft-sensor model, dashboard, integration or other software system, even if they never say "SDS". Also use it when updating or reviewing an existing SDS.
---

# foom Software Design Specification (SDS)

Produce a clear, professional SDS for foom GmbH that follows IEEE Std 1016 (software design descriptions) and sits within the ISO/IEC/IEEE 12207, 29148 and 42010 family. The output is a real document people read and edit, never a markdown dump in chat.

## Decide the mode first

1. **Template mode** — the user wants an empty, reusable SDS. Keep every bracketed `[Write here: ...]` instruction in place so the author can fill it in. Do not invent project facts.
2. **Filled mode** — the user supplies a project, code, an SRS, notes or a description. Fill each section with real content taken from those inputs.
3. **Update or review mode** — the user points to an existing SDS. Change only what was asked, and check traceability and numbering after edits.

If the request does not make the mode clear, default to template mode and offer to fill it in.

## Structure

Always use the section structure in `references/template-structure.md`. It is the approved foom layout: Document Control, 1 Introduction, 2 System Architecture, 3 Data Design, 4 Component Design, 5 User Interface Design, 6 Design Constraints and Security, 7 Requirements Traceability and Design Decisions, Appendices. Keep the numbering and heading names stable, because reviewers and other documents cite sections by number (for example "see 4.2"). Remove nothing silently: a section that does not apply stays with "Not applicable" and a one-line reason.

For filled mode, read `references/filling-guidance.md` for what good content looks like in each section.

## Output format

1. **Claude Docs tools connected:** create a doc, not a file. Follow the connector's own instructions: birth the doc first with a title, byline and one pending block per section, open it for the user, then fill one section per call. Tables in the template are real tables people edit in place.
2. **No Claude Docs tools, user wants Word or names .docx:** read the docx skill and build a .docx with the same structure and real tables.
3. **No Claude Docs tools and no format named:** say so, then offer the .docx.
4. Diagram sections (architecture, ERD, class, sequence, navigation flow) are placeholders in template mode. In filled mode, draw them as diagrams when the tools allow it; otherwise leave a clearly marked placeholder with a one-line description of what the diagram must show.
5. Finish with one short line and the link or file. Never repeat the document in chat.

## Rules for content

- **Never invent facts.** In filled mode, anything not found in the user's material becomes a visible `[To be confirmed: ...]` item and is added to section 7.3 (Risks and Open Issues).
- **Lead with decisions.** Open each section with the decision or result, then the detail. Explain why an architecture or technology was chosen and what was rejected.
- **Specifics over adjectives.** Use numbers, units, names, versions and requirement IDs. Label units in table headers.
- **Trace everything.** Every SRS requirement maps to a design element and a test in 7.1. Give modules, interfaces, screens and decisions stable IDs (MOD-01, IF-01, SCR-01, DD-01) and reuse them across sections.
- **Match the project type.** For data and ML work (pipelines, soft sensors, analytics scripts), stress data sources, units, validation rules, missing-data handling, model inputs and outputs, and retraining. For apps with users, stress screens, roles and security. If section 5 has no UI, mark it not applicable.
- **Keep plain, short sentences.** Paragraphs of three sentences or fewer. Bullets only for parallel items.
- **Document control matters.** Always fill or leave visible: document ID, version, status, author, reviewer, approver, date and the revision history. Increase the version and add a revision row whenever the SDS changes.

## Quality check before handing over

- Numbering is continuous and cross-references point to real sections.
- Every module, interface and screen listed in sections 4 and 5 appears in the traceability matrix or is explained.
- No leftover `[Write here: ...]` text in filled mode, no invented values, and no empty tables.
- The company name is foom GmbH, Berlin, and the standard references in 1.5 are present.
