# Filling guidance (filled mode)

Read the user's inputs completely first (code, notebooks, SRS, notes). Build a short fact list: purpose, inputs, outputs, modules, data stores, technologies, users, constraints. Fill the SDS only from that list, and send gaps to 7.3 as `[To be confirmed: ...]`.

## Where each fact goes
- Purpose and goals of the system: 1.1 and 1.2. State out-of-scope items explicitly.
- Libraries, languages, services, hosting: 2.4 and 2.5, each with a reason.
- Files, tables, columns, units, value ranges: 3.3. Copy column names exactly from the code or schema.
- Functions, scripts, notebooks, pipeline stages: one module each in 4.1 with inputs, outputs, dependencies and error handling as the code actually behaves.
- Function-call order or message order: sequence diagram in 4.2.
- Limits found in the code or brief (hardware, deadlines, data volume): 6.1.
- Credentials handling, access control, personal data: 6.2. If the code stores secrets in plain text, record it in 7.3 as a risk instead of describing an ideal design.

## Documenting existing code
Describe what the code does, not what it should do. Where behaviour looks odd or unverifiable, flag it in 7.3 rather than guessing. Leave design decisions blank in 7.2 unless the user or the code comments give the reason.

## Data and ML projects
- 3.1 to 3.5: sources, sampling rate or batch cadence, units, merge keys, validation and outlier rules, missing-data handling, retention.
- 4.1: one module per stage (ingestion, cleaning, feature building, training, inference, reporting). Give model inputs and outputs with units, target variable, validation method and metrics.
- 6.3: accuracy targets, retraining triggers, run time.

## Style
Lead each section with its point. Use IDs consistently (MOD-01, IF-01, SCR-01, DD-01, R-01). Keep tables to the columns in the template; delete empty example rows in filled mode.
