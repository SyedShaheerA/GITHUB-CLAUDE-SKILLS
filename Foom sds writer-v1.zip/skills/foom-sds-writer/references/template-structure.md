# foom SDS template structure

Use this exact outline. In template mode keep the bracketed instructions. Tables use the columns shown.

## Document Control
Intro line: replace every bracketed instruction with your own content, then delete the bracket text. Sections that do not apply stay with "Not applicable" and a one-line reason.
Table (Field | Value): Project name, Document ID, Version, Status, Company (foom GmbH, Berlin), Author(s), Reviewer(s), Approver, Date.
### Revision History
Table: Version | Date | Author | Description of change

## 1. Introduction
- 1.1 Purpose: why the document exists, who it is for.
- 1.2 Scope: in scope, out of scope, interfaces to other foom systems.
- 1.3 Intended Audience and Stakeholders: table Stakeholder | Role | Design concerns.
- 1.4 Definitions, Acronyms and Abbreviations: table Term | Definition (start with API, ERD, SDS).
- 1.5 References: IEEE Std 1016; ISO/IEC/IEEE 12207, 29148, 42010; the SRS (ID and version); other internal foom documents.
- 1.6 Document Overview: how the document is organised, what each stakeholder reads first.

## 2. System Architecture
- 2.1 Architectural Design: style (client-server, microservices, layered, pipeline, MVC), why chosen, alternatives rejected.
- 2.2 Design Viewpoints and Concerns: table Viewpoint | Concern it addresses | Where covered. Rows: Context (2.3), Composition (4), Information (3), Interface (4.3 and 5), Interaction (4.2), Deployment (2.5), Security (6).
- 2.3 Architecture Diagram: components, data stores, external systems, direction of data flow, plus one or two sentences of explanation.
- 2.4 Technology Stack: table Layer | Technology | Reason for choice (ingestion, storage, processing, presentation).
- 2.5 Deployment and Environment: where it runs, environments (dev, staging, production), hardware and network dependencies.

## 3. Data Design
- 3.1 Database Description: technology, why, how data is written, read and kept.
- 3.2 Entity Relationship Diagram (ERD): tables, PKs, FKs, relationships with cardinality.
- 3.3 Data Dictionary: one block per table, "Table: name — description", then table Column | Data type | Key | Nullable | Unit | Description.
- 3.4 Data Flow: source to storage to output; a data flow diagram if more than three steps.
- 3.5 Data Quality, Retention and Backup: table Topic | Design decision (validation rules, missing or invalid data, retention period, backup and recovery).

## 4. Component Design
- 4.1 Module Descriptions: one table per module, Attribute | Description with rows Module ID, Purpose, Inputs, Outputs, Dependencies, Processing logic, Error handling, Related requirements.
- 4.2 Class Diagrams and Sequence Diagrams: one-line caption under each.
- 4.3 Interface Design: table Interface ID | Between | Type | Data exchanged | Protocol or format.

## 5. User Interface Design
Note: if there is no UI, write "Not applicable" under 5.1 with the reason.
- 5.1 UI Overview: layout, colour scheme, design philosophy, target devices, foom brand guidelines.
- 5.2 Screen Mockups and Wireframes: images with captions, plus table Screen ID | Screen name | Purpose | Main elements.
- 5.3 Screen Navigation Flow: flow chart or state diagram.

## 6. Design Constraints and Security
- 6.1 Constraints: list, plus table ID | Constraint | Source | Impact on design.
- 6.2 Security Architecture: table Area | Design decision with rows Authentication, Authorization, Password and secret handling (bcrypt, vault), API protection (JWT, rate limiting), Data in transit (HTTPS, TLS 1.2+), Data at rest, Audit and logging, Personal data and GDPR.
- 6.3 Quality Attributes: table Attribute | Target | How the design meets it (performance, reliability and availability, scalability, maintainability, usability).

## 7. Requirements Traceability and Design Decisions
- 7.1 Traceability Matrix: Requirement ID | Requirement summary | Design element | Section | Test case ID.
- 7.2 Design Decision Log: ID | Date | Decision | Alternatives considered | Reason | Decided by.
- 7.3 Risks and Open Issues: ID | Description | Type | Owner | Mitigation or next step.

## Appendices
- Appendix A: Supporting Diagrams and Material.
- Appendix B: Approval Sign-off, table Name | Role | Signature | Date (Author, Reviewer, Approver).

Title format: "Software Design Specification (SDS) Template — foom GmbH" for the template; "<Project name> — Software Design Specification" for a filled SDS.
Byline: as-of date and author. Subtitle line: "Based on IEEE 1016 / ISO/IEC/IEEE 12207 design documentation practice".
