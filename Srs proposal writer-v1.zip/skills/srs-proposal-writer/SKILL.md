---
name: srs-proposal-writer
description: Draft software project proposals and write Software Requirements Specifications (SRS) using the Wiegers/Seilevel SRS template (Introduction, Overall Description, System Features, Data Requirements, External Interfaces, Quality Attributes, Internationalization, Other Requirements, Glossary, Analysis Models). Use this skill whenever the user wants to write a proposal, requirements document, SRS, spec, project documentation, or technical write-up for a software, data pipeline, ML, or integration project - including documenting an existing codebase or script after the fact, updating an SRS, turning rough notes or a repo into formal requirements, or preparing a project pitch for a manager or funder. Trigger even if the user does not say "SRS" and just says "document my project", "write up this system", "draft a proposal for this tool", or "requirements for this feature".
---

# SRS & Proposal Writer

Produces two kinds of document for software work, both anchored on the user's SRS template (bundled at `assets/Software_Requirements_Specification_Template.docx`, section guidance in `references/srs-sections.md`):

1. **Proposal** - a short, persuasive document that argues a project is worth doing. Structure in `references/proposal-structure.md`.
2. **SRS** - the full requirements specification, following the template's section numbering exactly.

A proposal is usually written first and becomes the seed for SRS sections 1-2 once the project is approved, so write them so content carries over without rewriting.

## Step 1: Pick the mode

| The user says... | Mode |
|---|---|
| "proposal", "pitch", "justify", "get approval/funding" | Proposal |
| "requirements", "spec", "SRS" for something new or planned | New SRS |
| "document my project/script/pipeline/repo" for something that already exists | As-built SRS (read `references/documenting-existing-software.md`) |
| "update", "add a feature to", "new version of" an existing SRS | Revision (bump version, add Revision History row, change only what is affected) |

If it is unclear, pick the most likely mode, say so in one line, and proceed.

## Step 2: Gather material before asking questions

Look first at what is already available: the conversation, uploaded files, pasted code or notebooks, READMEs, configs, and any connected tools. Most of an SRS can be drafted from that. Then ask only for what is genuinely missing and cannot be reasonably assumed. Group questions in a single message, three to five at most. The usual essentials:

- Who are the users/stakeholders and who will read the document?
- What problem does it solve and what does success look like?
- Hard constraints (technology, regulation, deadlines, budget, environment)?
- What is in scope now versus later?

If the user does not answer or wants a fast draft, proceed anyway: write down each guess under Assumptions and Dependencies (2.5) and mark open items `TBD`. A draft with visible gaps is more useful than a stalled conversation, and the template itself endorses `TBD` as a placeholder.

## Step 3: Draft

### Rules that apply to every section

- **Keep the template's structure and numbering.** The user chose this template so documents look consistent across projects. Do not rename, merge, or reorder sections. If a section does not apply, keep the heading and write "Not applicable - <one-line reason>". The only exceptions the template itself allows: Section 8 (Other Requirements) may be omitted if empty, Section 10 (Analysis Models) is optional, and 6.5 can be expanded into several quality attributes.
- **Replace every angle-bracket instruction.** The `<...>` text in the template is guidance to the author. It must not survive into the output.
- **Say what, not how.** Requirements describe what the system must do or be. Design choices (which library, which table layout) belong in Constraints only when they are genuinely mandated; otherwise leave them to design documents. This keeps the SRS valid when the implementation changes.
- **Write verifiable requirements.** Each requirement should be testable: "The system shall refresh the dashboard within 5 minutes of new data arriving" rather than "The dashboard should be fast". If you cannot make something quantitative yet, write `TBD` with the metric that needs a value, for example "TBD - target latency".
- **Give every functional requirement a unique ID** in the form `REQ-<FEATURE>-<nnn>` (e.g. `REQ-INGEST-003`) and use "shall" for mandatory, "should" for desirable. Record this convention in section 1.2 so later authors follow it. Quality attributes use `QA-<ATTR>-<nnn>`.
- **Prioritise features** High / Medium / Low in 3.x.1, as the template requires.
- **One idea per requirement.** If a sentence contains "and" joining two behaviours, split it.
- **Include error behaviour.** The template asks how the product responds to anticipated error conditions; a feature without failure handling is incomplete.
- **Define terms once, in the Glossary**, and use them consistently. Spell out each acronym on first use.
- **Link rather than duplicate** when a reference document already holds the detail (data dictionary, UI specification, vision and scope).
- **Diagrams**: context diagram (2.1), entity-relationship diagram (4.1), and state or data-flow models (10) add real value. Draw them as Mermaid when the output is markdown, or render to an image when the output is a Word file.
- **Do not invent facts.** Anything not given by the user or verified in the source material is an assumption and must be labelled as one.

### Proposal
Follow `references/proposal-structure.md`. Aim for 2-4 pages. Lead with the problem and outcome, not the technology.

### SRS
Work through `references/srs-sections.md` in order. Draft Sections 1 and 2 first, then list the features before detailing any of them, so scope is agreed before depth. For data-heavy projects (pipelines, analytics, ML, soft sensors) Section 4 carries more weight than usual: cover sources, schemas, quality rules, lineage, model inputs/outputs, and retention, and use 6.5 for freshness, reproducibility, and accuracy targets.

## Step 4: Check before delivering

Run this checklist silently and fix what fails:

- Every template section is present, in order, with the original numbering.
- No leftover `<...>` guidance text, no "System Feature 1" placeholder names.
- Every requirement has an ID, is testable, and uses shall/should consistently.
- Every term in the Glossary is used, and every specialised term used is in the Glossary.
- Cover page and Revision History are filled (project name, version, author, organization, date). Use today's date; version `0.1 draft` unless the user says otherwise.
- Assumptions, `TBD`s, and inferred (not verified) items are visible, not buried.
- References list real, accessible items only.

## Step 5: Deliver

Match the output to what the user asked for:

- **Word file requested, or they want the original template look**: fill a copy of `assets/Software_Requirements_Specification_Template.docx` using the `docx` skill's edit workflow (unzip, edit `word/document.xml`, rezip, validate). Preserve its styles and header/footer, replace placeholder text and the `<Project>`, `<author>`, `<organization>`, `<date created>` fields, and update the table of contents fields. If editing the template proves impractical, build a new .docx with matching headings and numbering.
- **No format named**: use the session's preferred document form (a doc or document artifact if one is offered), otherwise a Markdown or Word file. A long SRS belongs in a file, not in chat.
- **Short proposal or a single section**: put it in the reply.

After delivery, give a brief summary of the assumptions made and the `TBD`s that most need the user's input, so they know where to look first. Do not recap the document itself.
