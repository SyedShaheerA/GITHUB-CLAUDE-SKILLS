# SRS Section Guide

Follows the Wiegers/Seilevel template section by section. For each section: what belongs, what to check, and common mistakes. Template numbering is fixed.

## Contents
- Cover page and Revision History
- 1 Introduction
- 2 Overall Description
- 3 System Features
- 4 Data Requirements
- 5 External Interface Requirements
- 6 Quality Attributes
- 7 Internationalization and Localization
- 8 Other Requirements
- 9 Glossary
- 10 Analysis Models

## Cover page and Revision History
Title "Software Requirements Specification for <Project>", version, author, organization, date. Revision History table columns: Name, Date, Reason For Changes, Version. Add a row on every change, newest last.

## 1 Introduction
Short orientation so a reader knows how to use the document.

- **1.1 Document Purpose** - Name the product and release/version covered. List intended readers (developers, project managers, testers, users, documentation writers, funders) and say which sections matter most to each.
- **1.2 Document Conventions** - Requirement ID format (`REQ-<FEATURE>-<nnn>`, `QA-<ATTR>-<nnn>`), shall/should meaning, priority scale (High/Medium/Low), meaning of any text styling, `TBD` usage.
- **1.3 Project Scope** - What the software is and why it exists, tied to user or business goals. State what is in this release and, equally useful, what is explicitly out. Link to a vision/scope document rather than copying it. Give a high-level list of major features.
- **1.4 References** - Each item needs title, author, version, date, and location or URL. Include standards, related SRSs, API docs, data source documentation, style guides, contracts.

Mistake to avoid: a scope that is only a feature list. Add the goal each feature serves.

## 2 Overall Description
High-level context before detail.

- **2.1 Product Perspective** - Origin: new product, replacement, next version, or component of a larger system. If a component, name the parent system and the main interfaces. A context diagram (Mermaid `flowchart`) showing external actors and systems is strongly recommended.
- **2.2 User Classes and Characteristics** - One entry per user class: who they are, technical skill, frequency of use, which features matter to them, and which classes are favored. Include non-human actors that consume outputs (downstream systems, schedulers) if relevant.
- **2.3 Operating Environment** - Hardware, OS and versions, runtime/language versions, hosting (cloud, on-premises, edge), geography of users/servers/data stores, and software it must coexist with. If large infrastructure work is needed, suggest a separate infrastructure specification.
- **2.4 Design and Implementation Constraints** - Only real limits: regulation and company policy, mandated technologies/tools/databases, language restrictions, hardware limits (memory, timing), required interfaces, licensing. Each constraint should say where it comes from.
- **2.5 Assumptions and Dependencies** - Assumptions are unverified beliefs that could break requirements if wrong. Dependencies are external things outside the team's control (third-party APIs, data feeds, other teams' deliverables, hardware availability). Every guess you made while drafting goes here.

## 3 System Features
Functional requirements grouped by feature. The template suggests features but allows organizing by use case, user class, mode, or stimulus when that fits better. Choose one scheme and use it throughout.

Repeat for each feature (3.1, 3.2, ...). Use a real feature name, never "System Feature 1".

- **3.x.1 Description** - Two to four sentences plus priority (High/Medium/Low). Say what value it gives and to whom.
- **3.x.2 Stimulus/Response Sequences** - Numbered steps: user or system action, then system response. Include the main flow and the key alternative and error flows. These later become test cases.
- **3.x.3 Functional Requirements** - Itemized, each with an ID, a single testable "shall" statement, and the behaviour on anticipated errors (invalid input, missing data, timeout, unavailable dependency). Use `TBD` where information is missing and list what is needed.

Example:
```
REQ-INGEST-001  The system shall read new sensor files from the configured landing folder at least once every 15 minutes.
REQ-INGEST-002  If a file fails schema validation, the system shall move it to the quarantine folder, log the filename and failing rule, and continue with the remaining files.
```

## 4 Data Requirements
What data the system consumes, processes, and produces.

- **4.1 Logical Data Model** - Entities and relationships, usually an ER diagram (Mermaid `erDiagram`). Logical, not physical: no indexes or storage engines.
- **4.2 Data Dictionary** - For each element: name, meaning, type, length/precision, format, units, allowed values or ranges, source. If it is large, keep it as a separate artifact (e.g. a spreadsheet) and link it here.
- **4.3 Reports** - Each report or output table: purpose, audience, content, sort order, totals, frequency. Defer visual layout to design unless a layout is mandated.
- **4.4 Data Acquisition, Integrity, Retention, and Disposal** - How data arrives, validation and quality rules, backup/mirroring/checkpointing, how long each class of data is kept (including temporary, cached, archived, deleted records), and how it is disposed of.

For analytics, pipeline, and ML projects add here: source systems and refresh cadence, data lineage from raw to curated to model input, handling of missing and out-of-range values, labelling and ground-truth sources, train/validation split policy, and model input/output definitions.

## 5 External Interface Requirements
Everything crossing the system boundary.

- **5.1 User Interfaces** - Logical characteristics only: screens or CLI/notebook interaction, standard elements, error message conventions, accessibility rules, style guides followed. Link a separate UI specification for detail. If there is no UI (batch job, library), say so and describe how users invoke and observe it.
- **5.2 Software Interfaces** - Each connected component by name and version: purpose, message/data formats and contents, field mappings and transformations, services used, expected response times, security controls.
- **5.3 Hardware Interfaces** - Device types, protocols, inputs/outputs with formats and valid ranges, timing. "Not applicable" is a valid answer for pure software.
- **5.4 Communications Interfaces** - Protocols, message formatting, encryption, transfer rates, synchronization, constraints (e.g. no email attachments).

## 6 Quality Attributes
Make each one specific, quantitative, and verifiable, with an ID. If one feature has its own performance target, state it in that feature instead.

- **6.1 Usability** - Learnability, efficiency, error recovery, accessibility, standards followed.
- **6.2 Performance** - Response times, throughput, data volumes, batch windows, under what load.
- **6.3 Security** - Authentication, authorization, data protection, privacy rules, regulations (e.g. GDPR where personal data is involved), audit needs.
- **6.4 Safety** - Possible harm or loss from use, safeguards, prevented actions, certifications. For industrial or process-control settings treat this seriously; otherwise "Not applicable" with reason.
- **6.5 Others as relevant** - One subsection per attribute that matters: availability, reliability, scalability, maintainability, portability, interoperability, reproducibility, observability, accuracy. State relative priorities when they conflict (e.g. security over performance).

## 7 Internationalization and Localization Requirements
Languages, character sets, date/number/currency formats, units, time zones, name order, legal differences. If the product is single-locale, state the locale and that no others are required.

## 8 Other Requirements
Legal, regulatory, installation/configuration/startup/shutdown, logging, monitoring, audit trails, licensing. Prefer adding properly named sections over a catch-all. Omit this section if everything fits elsewhere.

## 9 Glossary
Alphabetical. Spell out each acronym and give a one-line definition in project context.

## 10 Analysis Models
Optional. Data-flow diagrams, feature trees, state-transition diagrams, ER diagrams, or pointers to them. Models may instead sit in the relevant sections; if so, say so here or omit the section.
