# Proposal Structure

The SRS template does not include a proposal format, so this is a deliberately small structure designed to feed into the SRS later. Target length: 2-4 pages. Write for a decision-maker who has five minutes: the first half page must make the case.

## Sections

1. **Title block** - Project name, author, organization, date, version, audience.
2. **Summary** - Three to five sentences: the problem, the proposed solution, the expected outcome, and the ask (approval, budget, time, access).
3. **Problem and Opportunity** - What is happening today, who is affected, what it costs (time, money, risk, quality), with evidence or numbers when available. *Seeds SRS 1.3 and 2.1.*
4. **Proposed Solution** - What will be built, in plain language, and how users will experience it. Include a simple context diagram when it helps. *Seeds SRS 2.1 and the feature list in 3.*
5. **Scope** - In scope now, explicitly out of scope, and possible later phases. *Seeds SRS 1.3.*
6. **Users and Stakeholders** - Who benefits, who decides, who must be consulted. *Seeds SRS 2.2.*
7. **Benefits and Success Measures** - Measurable outcomes (e.g. reduce manual processing from 4 h to 30 min per week). Separate hard benefits from soft ones.
8. **Approach and Timeline** - Phases or milestones with rough durations and deliverables. Name key technologies only when a constraint or choice needs justifying. *Seeds SRS 2.3 and 2.4.*
9. **Resources and Effort** - People, time, infrastructure, data access, tooling, and costs. Mark estimates as estimates.
10. **Risks, Assumptions, and Dependencies** - Top risks with likelihood, impact, and mitigation; what is assumed; what is outside the team's control. *Seeds SRS 2.5.*
11. **Next Steps** - The decision requested and what happens after approval, including that a full SRS will follow.

## Writing guidance
- Lead with outcomes, not technology.
- Quantify wherever possible; say "estimate" or `TBD` rather than inventing numbers.
- Tailor tone to the reader: a manager wants impact and effort; a funder wants innovation, feasibility, and measurable results; a technical reviewer wants constraints and risks. If the audience is unknown, default to manager.
- Keep it to what the reader needs to decide. Detail belongs in the SRS.
- If a grant or tender has its own required headings, use those headings and map the content above onto them.
