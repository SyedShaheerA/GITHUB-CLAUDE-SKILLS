# Documenting Existing Software (As-Built SRS)

Use when the system already exists (a repo, script, notebook, pipeline, service) and the user wants it documented in SRS form. The risk here is writing what the code *should* do instead of what it *does*, or presenting guesses as facts. Keep verified and inferred content visibly separate.

## 1. Survey before writing
Read, in this order, whatever is available: README and docs, directory layout, entry points and scheduler/config files, dependency manifests (requirements.txt, package.json, environment files), data schemas or sample data, tests, then the core logic. For notebooks, read cells in order and note inputs, transformations, and outputs. Do not read everything line by line when the structure answers the question; sample, then go deeper where behaviour is unclear.

## 2. Map code to SRS sections

| Look at | Feeds |
|---|---|
| README, docstrings, commit history | 1.3 Scope, 2.1 Perspective |
| Who runs it, who consumes outputs | 2.2 User Classes |
| Runtime versions, dependencies, deployment config | 2.3 Operating Environment, 5.2 Software Interfaces |
| Mandated libraries, compliance notes, hard-coded limits | 2.4 Constraints |
| Entry points, CLI arguments, scheduled jobs, main flow | 3 System Features and Stimulus/Response |
| Validation, exception handling, retries | Error behaviour in 3.x.3 |
| Schemas, column names, units, config tables | 4.1 Logical Data Model, 4.2 Data Dictionary |
| Output files, tables, plots, exports | 4.3 Reports |
| Read/write paths, file retention, backups | 4.4 Data handling |
| APIs, databases, file shares, protocols | 5.2-5.4 Interfaces |
| Timeouts, batch sizes, logging, auth code | 6 Quality Attributes |

## 3. Label evidence
- State requirements as observed behaviour ("The system reads ... and writes ...").
- Where purpose or intent is not evident from the code, write it as an assumption in 2.5 and mark it for the owner to confirm. Do not guess business rules, thresholds, or units.
- Where code and documentation disagree, or something looks like a bug or dead code, list it under a "Discrepancies and open questions" subsection in Section 8 (create it) rather than silently choosing one.
- Quantitative targets (performance, accuracy) that the code does not enforce become `TBD`, optionally noting the observed value ("currently about 12 minutes per run, target TBD").

## 4. Write for the maintainers
The as-built SRS should let a new team member understand what the system is for, what it needs, what it produces, and where it is fragile. Prefer a data dictionary and a feature-by-feature description with concrete file, table, and column names (these are facts, not design speculation) over generic prose.

## 5. Offer follow-up
End with the list of open questions and inferred items so the owner can confirm them in one pass; update the document and bump the Revision History when they answer.
